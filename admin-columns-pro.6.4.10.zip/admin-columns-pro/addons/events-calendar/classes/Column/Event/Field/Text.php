<?php

namespace ACA\EC\Column\Event\Field;

use ACA\EC\Column\Event;

/**
 * @since 1.1.2
 */
class Text extends Event\Field {

}