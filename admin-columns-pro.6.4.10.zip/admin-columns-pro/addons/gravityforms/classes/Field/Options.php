<?php

namespace ACA\GravityForms\Field;

interface Options {

	/**
	 * @return array
	 */
	public function get_options();

}