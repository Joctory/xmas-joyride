<?php

namespace ACA\ACF\Field;

interface Textarea {

	/**
	 * @return int
	 */
	public function get_rows();

}