<?php

namespace ACA\ACF\Field;

interface TaxonomyFilterable {

	public function get_taxonomies(): array;

}